namespace N
{
	class input_text
	{
	public:

		/*
		Reads input text from keyboard
		char inputchar is he input character captured from keyboard
		*/
		void Read_text(char inputchar[1]);
	};

}